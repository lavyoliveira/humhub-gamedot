<?php
	return [
		'<strong>Steam</strong>' => '<strong>Steam</strong>',
		'Steam Settings' => 'Steam 設定',
		'Steam Widget URL:' => 'SteamウィジェットURL：',
		'<strong>Steam</strong> module configuration' => '<strong>Steam</strong> モジュール構成',
		'Save' => 'セーブ',
	];
