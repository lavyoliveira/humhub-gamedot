<?php
	return [
		'<strong>Steam</strong>' => '',
		'Steam Settings' => '',
		'Steam Widget URL:' => '',
		'<strong>Steam</strong> module configuration' => '',
		'Save' => '',
	];
