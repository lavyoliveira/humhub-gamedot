<?php
return [
    '<strong>Steam</strong>' => '<strong>Steam</strong>',
    'Steam Settings' => 'Steam Ayarlar',
    'Steam Widget URL:' => 'Steam Widget URL:',
    '<strong>Steam</strong> module configuration' => '<strong>Steam</strong> modül yapılandırması',
    'Save' => 'Kaydet',
];
