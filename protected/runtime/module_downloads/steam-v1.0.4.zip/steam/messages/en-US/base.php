<?php

	return [
		'<strong>Steam</strong>' => '<strong>Steam</strong>',
		'Steam Settings' => 'Steam Settings',
		'Steam Widget URL:' => 'Steam Widget URL:',
		'<strong>Steam</strong> module configuration' => '<strong>Steam</strong> module configuration',
		'Save' => 'Save',
	];
