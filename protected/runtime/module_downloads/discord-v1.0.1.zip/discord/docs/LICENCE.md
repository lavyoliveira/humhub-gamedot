# Licenses

- Green Meteor licenses at: https://greenmeteor.net/p/licences
