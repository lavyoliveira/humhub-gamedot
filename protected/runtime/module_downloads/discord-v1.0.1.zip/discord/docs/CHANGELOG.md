Changelog
=========

### 1.0.2 (Unreleased)

- Enh: New `sendMessage()` function, this function ***should*** send a message to your Discord server on new connection still testing function for future release!

### 1.0.1 (8/8/2021)

- Enh: Implement hiding of `clientSecret`(i.e. added`textInput(['type' => 'password'])`) as requested by client

### 1.0.0 (2/8/2021)

- Initial release
